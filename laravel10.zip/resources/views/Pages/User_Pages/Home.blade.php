@extends('Template.User_Template.Master_User')

@section('title','Reservasi Ciwidey - Home')

@section('konten')
<h1>halaman home</h1>
@endsection

