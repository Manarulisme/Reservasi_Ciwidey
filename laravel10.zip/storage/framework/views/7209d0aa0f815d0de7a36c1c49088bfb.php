<?php $__env->startSection('title','Reservasi Ciwidey - Home'); ?>

<?php $__env->startSection('konten'); ?>
<h1>halaman home</h1>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Template.User_Template.Master_User', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Reservasi_Ciwidey\resources\views/Pages/User_Pages/Home.blade.php ENDPATH**/ ?>